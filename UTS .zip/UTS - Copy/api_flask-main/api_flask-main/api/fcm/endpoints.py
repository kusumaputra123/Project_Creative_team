"""Routes for module protected endpoints"""
import firebase_admin.exceptions
from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from helper.jwt_helper import get_roles



firebase_messaging = Blueprint('firebase_messaging', __name__)


@firebase_messaging.route('/send', methods=['POST'])
@jwt_required()
def send():
    """
    Routes for demonstrate protected data endpoints, 
    need jwt to visit this endpoint
    """
    try:
        current_user = get_jwt_identity()
        roles = get_roles()
        return jsonify({"message": "Notification sent successfully!",
                        "user_logged": current_user['username'],
                        "roles": roles}), 200
    except firebase_admin.exceptions.FirebaseError as e:
        print(e)
        return {'error': 'Failed to send notification'}, 500
